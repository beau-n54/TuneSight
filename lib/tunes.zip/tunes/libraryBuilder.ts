import path from "path";
import { LibraryFile } from "./libraryScanner";
import { RomLibraryEntry } from "./romLibrary";

function inferPlatformFromPath(fullPath: string): string {
  const upperPath = fullPath.toUpperCase();

  if (upperPath.includes("N20")) return "N20";
  if (upperPath.includes("N13")) return "N13";

  if (upperPath.includes("B58") && upperPath.includes("GEN2")) return "B58 Gen2";
  if (upperPath.includes("B58") && upperPath.includes("GEN 2")) return "B58 Gen2";
  if (upperPath.includes("B58GEN2")) return "B58 Gen2";
  if (upperPath.includes("B58TU")) return "B58 Gen2";
  if (upperPath.includes("B58")) return "B58 Gen1";

  if (upperPath.includes("S55")) return "S55";
  if (upperPath.includes("S58")) return "S58";
  if (upperPath.includes("S63")) return "S63";
  if (upperPath.includes("N55")) return "N55";
  if (upperPath.includes("N54")) return "N54";

  return "Unknown";
}

function inferEngineFamily(platform: string): string {
  if (platform === "B58 Gen2") return "B58TU";
  if (platform === "B58 Gen1") return "B58";
  return platform === "Unknown" ? "Unknown" : platform;
}

function inferEcuFromPath(fullPath: string, fileName: string): string {
  const haystack = `${fullPath} ${fileName}`.toUpperCase();

  if (haystack.includes("MG1CS201")) return "MG1CS201";
  if (haystack.includes("MG1CS003")) return "MG1CS003";
  if (haystack.includes("MG1CS024")) return "MG1CS024";
  if (haystack.includes("MG1CS011")) return "MG1CS011";
  if (haystack.includes("MG1CS002")) return "MG1CS002";
  if (haystack.includes("MG1CS")) return "MG1CS";

  if (haystack.includes("MG1")) return "MG1";
  if (haystack.includes("MD1")) return "MD1";

  if (haystack.includes("MSD87")) return "MSD87";
  if (haystack.includes("MSD85")) return "MSD85";
  if (haystack.includes("MSD81")) return "MSD81";
  if (haystack.includes("MSD80")) return "MSD80";

  if (haystack.includes("MEVD172G")) return "MEVD17.2.G";
  if (haystack.includes("MEVD1726")) return "MEVD17.2.6";
  if (haystack.includes("MEVD172")) return "MEVD17.2";
  if (haystack.includes("MEVD17")) return "MEVD17";

  if (haystack.includes("DME_86T0")) return "MG1CS201";
  if (haystack.includes("86T0")) return "MG1CS201";
  if (haystack.includes("86T1")) return "MG1CS201";
  if (haystack.includes("98G0B")) return "MG1CS201";

  return "Unknown";
}

function inferDefaultEcuFromPlatform(platform: string): string {
  if (platform === "N54") return "MSD80/MSD81";
  if (platform === "N55") return "MEVD17.2";
  if (platform === "N20") return "MEVD17.2";
  if (platform === "N13") return "MEVD17.2";
  if (platform === "B58 Gen1") return "MG1";
  if (platform === "B58 Gen2") return "MG1CS201";
  if (platform === "S55") return "MEVD17.2.G";
  if (platform === "S58") return "MG1CS201";
  if (platform === "S63") return "MEVD17/MG1";

  return "Unknown";
}

function normaliseName(fileName: string): string {
  return path.basename(fileName, path.extname(fileName)).toUpperCase();
}

function findRelatedFile(
  romFamily: string,
  files: LibraryFile[],
  category: LibraryFile["category"],
  samePlatformHint: string
): string | null {
  const target = romFamily.toUpperCase();

  const candidates = files.filter(
    (file) =>
      file.category === category &&
      inferPlatformFromPath(file.fullPath) === samePlatformHint
  );

  const exact = candidates.find(
    (file) => normaliseName(file.fileName) === target
  );

  if (exact) return exact.fileName;

  const partial = candidates.find((file) =>
    normaliseName(file.fileName).includes(target)
  );

  return partial?.fileName ?? null;
}

export function buildRomLibrary(files: LibraryFile[]): RomLibraryEntry[] {
  const library: RomLibraryEntry[] = [];

  for (const file of files) {
    if (file.category !== "xdf") continue;

    const romFamily = path.basename(file.fileName, path.extname(file.fileName));
    const platform = inferPlatformFromPath(file.fullPath);
    const engineFamily = inferEngineFamily(platform);

    const detectedEcu = inferEcuFromPath(file.fullPath, file.fileName);
    const ecu =
      detectedEcu !== "Unknown"
        ? detectedEcu
        : inferDefaultEcuFromPlatform(platform);

    library.push({
      platform,
      ecu,
      romFamily,
      engineFamily,
      xdfSuggested: file.fileName,
      stockBinSuggested:
        findRelatedFile(romFamily, files, "stockBin", platform) ??
        findRelatedFile(romFamily, files, "bin", platform),
      mapSwitchBinSuggested: findRelatedFile(
        romFamily,
        files,
        "mapSwitch",
        platform
      ),
      markers: [romFamily, platform, ecu].filter((value) => value !== "Unknown"),
    });
  }

  return library;
}