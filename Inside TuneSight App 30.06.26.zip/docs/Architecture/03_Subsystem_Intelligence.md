# Intelligence Subsystem

Version: Engineering Blueprint V2

Status:
🟢 Verified

Document:
03_Subsystem_Intelligence.md

Last Updated:
30 June 2026

Owner:
Intelligence Engine

Audit Sprint:
Pre-Sprint (Verified during Root Cause Engine and Universal Log Translator migration)

Primary Responsibility:
Transform translated vehicle data into diagnostic intelligence, evidence, rankings, and actionable recommendations.

Verification Method:

✔ Source code inspected

✔ Root Cause Engine verified

✔ Candidate Ranking verified

✔ Cross Reference verified

✔ Evidence pipeline verified

---

# Purpose

The Intelligence Subsystem is responsible for understanding vehicle behaviour.

It consumes a platform-independent Parsed Log and produces meaningful engineering conclusions.

The Intelligence Subsystem does not care whether the data originated from MHD, bootmod3, ProTool or any future logging platform.

It only consumes the Parsed Log supplied by the Logging Subsystem.

---

# Architecture

The Intelligence pipeline follows a single direction.

```
Parsed Log

↓

Analysis Engine

↓

Event Detection

↓

Evidence Collection

↓

Root Cause Engine

↓

Candidate Ranking

↓

Cross Reference

↓

Narrative Summary

↓

Dashboard
```

Each stage has a single responsibility.

---

# Responsibilities

The Intelligence Subsystem owns:

- Analysis Engine
- Event detection
- Evidence collection
- Root Cause Engine
- Candidate Ranking
- Confidence scoring
- Contradictory evidence handling
- Cross Reference generation
- Narrative summaries
- Tune intelligence
- Diagnostic recommendations

The Intelligence Subsystem does not own:

- CSV parsing
- Platform translation
- UI rendering
- Dashboard layout
- File uploads
- Database persistence

---

# Current Intelligence Components

## Analysis Engine

Responsible for extracting measurable events from the Parsed Log.

Examples:

- Overboost
- Underboost
- Boost taper
- Timing corrections
- HPFP limitation
- LPFP limitation
- Throttle closure
- Thermal events

---

## Evidence Engine

Responsible for collecting supporting and contradictory evidence.

Evidence is weighted before reaching the Root Cause Engine.

Examples:

- Boost error
- WGDC
- Rail pressure
- Throttle angle
- Timing corrections
- IAT
- Fuel trims

---

## Root Cause Engine

Responsible for generating engineering hypotheses.

Examples:

- Turbo Flow Limit
- WGDC Base Under-Commanded
- Boost Target / Load Strategy Mismatch
- HPFP Capacity Limit
- LPFP Drop
- Multi-Cylinder Timing Correction
- Overboost
- Boost Undershoot

Root causes compete with one another.

Multiple root causes may coexist.

---

## Candidate Ranking

Responsible for ordering competing hypotheses.

Ranking considers:

- Evidence strength
- Contradictory evidence
- Confidence weighting
- Diagnostic consistency

Candidate Ranking does not generate evidence.

It evaluates evidence produced earlier in the pipeline.

---

## Cross Reference

Responsible for connecting diagnostics to tune calibration.

Examples:

- Related XDF tables
- Boost control tables
- Fuel pressure tables
- Ignition tables
- Torque limiters
- Load limiters

Cross Reference never changes a tune.

It explains where the calibration responsible for a diagnosis is likely located.

---

## Narrative Engine

Responsible for transforming engineering conclusions into human-readable explanations.

Outputs include:

- Summary cards
- Evidence explanations
- Confidence explanations
- Diagnostic summaries

---

# Current Data Flow

```
Parsed Log

↓

Event Detection

↓

Evidence Collection

↓

Root Cause Engine

↓

Candidate Ranking

↓

Cross Reference

↓

Narrative Summary

↓

Telemetry

↓

Dashboard
```

Each stage consumes the output of the previous stage.

Information should never skip stages.

---

# Ownership Rules

The Intelligence Subsystem is the only owner of:

- Diagnostic reasoning
- Evidence weighting
- Root cause generation
- Candidate ranking
- Confidence calculation
- Cross-reference generation
- Narrative generation

No other subsystem should duplicate these responsibilities.

---

# Dependencies

## Depends On

- Parsed Log
- Vehicle metadata
- Tune profile
- Translation pipeline

---

## Used By

- Dashboard
- Analysis page
- Cross Reference cards
- Tune Profile
- Telemetry
- Future AI recommendation engine

---

# Technical Health

Status:

🟩 Healthy

Major achievements:

- Root Cause Engine established.
- Candidate Ranking operational.
- Contradictory evidence framework implemented.
- Cross Reference integrated.
- Evidence weighting operational.
- Universal logging integration completed.

---

# Technical Debt

Status:

🟧 Important

Current opportunities:

- Continue expanding root cause library.
- Increase calibration coverage.
- Improve confidence modelling.
- Expand supporting evidence relationships.
- Expand XDF knowledge base.
- Continue reducing duplicated helper logic.

The overall architecture is considered stable.

Future work is focused on expanding knowledge rather than changing ownership.

---

# Architecture Rules

The Intelligence Subsystem follows these permanent rules.

• Every diagnosis originates from evidence.

• Evidence is collected before reasoning.

• Root causes compete rather than overwrite one another.

• Candidate Ranking owns prioritisation.

• Cross Reference explains calibration relationships.

• Narrative generation never performs diagnosis.

• Logging translates.

• Intelligence reasons.

---

# Future Expansion

The subsystem has been designed to support:

- Additional root causes
- Additional evidence types
- Additional platforms
- ECU family intelligence
- Automatic calibration recommendations
- Binary modification recommendations
- Future AI-assisted optimisation

These capabilities should integrate into the existing pipeline without changing subsystem ownership.

---

# Long-Term Vision

The Intelligence Subsystem will become the engineering knowledge engine that powers TuneSight.

Its purpose is not simply to detect faults.

Its purpose is to understand why the vehicle behaves as it does, identify the most probable engineering causes, explain the supporting evidence, and guide the user toward the correct calibration changes.

Every future intelligence feature should extend this architecture rather than replace it.

---

# Audit History

## Root Cause Engine Evolution

Status:

🟢 Completed

Summary:

- Evidence pipeline established.
- Root Cause Engine verified.
- Candidate Ranking verified.
- Cross Reference verified.
- Universal Log Translator integration completed.
- Single intelligence ownership established.

---

This subsystem is considered the primary engineering reasoning engine within TuneSight and forms the foundation for all future diagnostic intelligence.