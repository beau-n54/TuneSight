# Logging Subsystem

Version: Engineering Blueprint V2

Status: 🟢 Verified

Document:
02_Subsystem_Logging.md

Last Updated:
30 June 2026

Owner:
Logging Engine

Audit Sprint:
Pre-Sprint (Verified during Universal Log Translator migration)

Primary Responsibility:
Translate raw log files into a platform-independent Parsed Log used by the Intelligence Engine.

Verification Method:

✔ Source code inspected

✔ Translation pipeline verified

✔ Universal Log Translator verified

✔ MHD migration completed

---

# Purpose

The Logging Subsystem is responsible for converting raw datalog files into a consistent internal format that can be consumed by every downstream subsystem.

It is the only subsystem that understands logging platform differences.

Every subsystem after logging operates on translated data only.

---

# Architecture

The logging pipeline follows a strict flow.

```
CSV

↓

Platform Detection

↓

Platform Translator

↓

Translated Log

↓

buildParsedLogFromTranslatedLog()

↓

Parsed Log

↓

Analysis Engine
```

No downstream subsystem should read raw CSV files directly.

---

# Responsibilities

The Logging Subsystem owns:

- CSV parsing
- Header detection
- Channel alias mapping
- Platform translation
- Universal Log Translator
- Parsed Log creation
- Logging statistics generation

The Logging Subsystem does **not** own:

- Diagnostic reasoning
- Root Cause analysis
- Candidate Ranking
- Tune comparison
- ROM detection
- Telemetry rendering
- Dashboard presentation

---

# Current Platform Support

## MHD

Status:

🟢 Verified

Translation handled by the Universal Log Translator.

---

## bootmod3 (BM3)

Status:

🟢 Existing translator verified.

BM3 maintains its own translator implementation.

Future work will migrate it toward the Universal Log Translator architecture where practical, while preserving compatibility.

---

## Future Platforms

Planned support includes:

- ProTool
- xHP
- Dimsport
- Custom CSV formats

Each platform should provide only a translator.

No platform should modify the Analysis Engine.

---

# Current Data Flow

```
Raw CSV

↓

Platform Translator

↓

Universal Log Format

↓

buildParsedLogFromTranslatedLog()

↓

Parsed Log

↓

Analysis Engine

↓

Root Cause Engine

↓

Candidate Ranking

↓

Cross Reference

↓

Telemetry

↓

Dashboard
```

This architecture establishes a single source of truth for all logging data.

---

# Ownership Rules

The Logging Subsystem is the only owner of:

- Raw CSV interpretation
- Header aliases
- Channel translation
- Unit normalisation
- Platform-specific naming

Once translation is complete, platform-specific information should no longer exist.

All downstream systems consume the same Parsed Log structure regardless of the original logging platform.

---

# Dependencies

## Depends On

- CSV upload
- File storage
- Vehicle metadata

---

## Used By

- Analysis Engine
- Root Cause Engine
- Candidate Ranking
- Cross Reference
- Telemetry
- Dashboard
- Tune Intelligence

---

# Technical Health

Status:

🟩 Healthy

Major achievements:

- Universal Log Translator implemented.
- MHD successfully migrated.
- Translation ownership centralised.
- Downstream systems consume translated data.
- Duplicate parsing significantly reduced.

---

# Technical Debt

Status:

🟨 Improvement

Future work:

- Consolidate remaining BM3 translation logic where appropriate.
- Add additional logging platform translators.
- Improve platform auto-detection.
- Expand channel alias library.

No architectural issues currently require immediate refactoring.

---

# Architecture Rules

The Logging Subsystem follows these permanent rules.

• Every logging platform supplies a translator.

• Every translator produces the same internal format.

• No downstream subsystem may interpret raw CSV files.

• Platform-specific logic ends at translation.

• The Parsed Log is the single source of truth for all analysis.

---

# Future Expansion

Additional translators should integrate without changing:

- Analysis Engine
- Intelligence Engine
- Candidate Ranking
- Cross Reference
- Telemetry

Adding a new logging platform should require only:

1. Platform detection.
2. Translator implementation.
3. Translator registration.

No other subsystem should require modification.

---

# Audit History

## Universal Log Translator Migration

Status:

🟢 Completed

Summary:

- MHD migrated to Universal Log Translator.
- Existing BM3 translator verified.
- Parsed Log pipeline standardised.
- Logging ownership centralised.
- Architecture verified.

---

This subsystem is considered stable and serves as the foundation for all diagnostic analysis within TuneSight.